﻿namespace YM_STORE
{
    partial class instruments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(instruments));
            checkBox1 = new CheckBox();
            pictureBox1 = new PictureBox();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox4 = new CheckBox();
            checkBox5 = new CheckBox();
            checkBox6 = new CheckBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            nextButton = new Button();
            button2 = new Button();
            panel1 = new Panel();
            label7 = new Label();
            label1 = new Label();
            totalLabel = new Label();
            button4 = new Button();
            button1 = new Button();
            button3 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            label8 = new Label();
            label9 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.ForeColor = Color.Pink;
            checkBox1.Location = new Point(145, 340);
            checkBox1.Margin = new Padding(4);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(97, 32);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "9999LE";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(66, 148);
            pictureBox1.Margin = new Padding(4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(248, 174);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.BackColor = Color.Transparent;
            checkBox2.ForeColor = Color.Pink;
            checkBox2.Location = new Point(537, 349);
            checkBox2.Margin = new Padding(4);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(97, 32);
            checkBox2.TabIndex = 2;
            checkBox2.Text = "4900LE";
            checkBox2.UseVisualStyleBackColor = false;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.ForeColor = Color.Pink;
            checkBox3.Location = new Point(909, 349);
            checkBox3.Margin = new Padding(4);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(97, 32);
            checkBox3.TabIndex = 3;
            checkBox3.Text = "9999LE";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.ForeColor = Color.Pink;
            checkBox4.Location = new Point(126, 640);
            checkBox4.Margin = new Padding(4);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(97, 32);
            checkBox4.TabIndex = 4;
            checkBox4.Text = "7999LE";
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.ForeColor = Color.Pink;
            checkBox5.Location = new Point(526, 640);
            checkBox5.Margin = new Padding(4);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(108, 32);
            checkBox5.TabIndex = 5;
            checkBox5.Text = "25000LE";
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.ForeColor = Color.Pink;
            checkBox6.Location = new Point(900, 645);
            checkBox6.Margin = new Padding(4);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(97, 32);
            checkBox6.TabIndex = 6;
            checkBox6.Text = "7500LE";
            checkBox6.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(468, 148);
            pictureBox2.Margin = new Padding(4);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(248, 174);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 13;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(837, 148);
            pictureBox3.Margin = new Padding(4);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(248, 174);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 14;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(66, 438);
            pictureBox4.Margin = new Padding(4);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(248, 174);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 15;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(468, 452);
            pictureBox5.Margin = new Padding(4);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(248, 175);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 16;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(828, 452);
            pictureBox6.Margin = new Padding(4);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(248, 174);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 17;
            pictureBox6.TabStop = false;
            // 
            // nextButton
            // 
            nextButton.ForeColor = Color.HotPink;
            nextButton.Location = new Point(605, 804);
            nextButton.Margin = new Padding(4);
            nextButton.Name = "nextButton";
            nextButton.Size = new Size(129, 41);
            nextButton.TabIndex = 18;
            nextButton.Text = "Next";
            nextButton.UseVisualStyleBackColor = true;
            nextButton.Click += nextButton_Click;
            // 
            // button2
            // 
            button2.Enabled = false;
            button2.ForeColor = Color.HotPink;
            button2.Location = new Point(468, 804);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.Size = new Size(129, 41);
            button2.TabIndex = 19;
            button2.Text = "Previous";
            button2.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            panel1.BackColor = Color.HotPink;
            panel1.Controls.Add(label7);
            panel1.Location = new Point(-10, -4);
            panel1.Margin = new Padding(4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1305, 116);
            panel1.TabIndex = 20;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.HotPink;
            label7.Font = new Font("Matura MT Script Capitals", 22.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.LavenderBlush;
            label7.Location = new Point(318, 30);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(544, 50);
            label7.TabIndex = 20;
            label7.Text = "MY  MUSIC STORE  ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(60, 782);
            label1.Name = "label1";
            label1.Size = new Size(98, 28);
            label1.TabIndex = 21;
            label1.Text = "Total EGP:";
            // 
            // totalLabel
            // 
            totalLabel.AutoSize = true;
            totalLabel.ForeColor = Color.Pink;
            totalLabel.Location = new Point(164, 782);
            totalLabel.Name = "totalLabel";
            totalLabel.Size = new Size(23, 28);
            totalLabel.TabIndex = 22;
            totalLabel.Text = "0";
            // 
            // button4
            // 
            button4.Location = new Point(86, 679);
            button4.Name = "button4";
            button4.Size = new Size(34, 29);
            button4.TabIndex = 23;
            button4.Text = "-";
            button4.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(106, 377);
            button1.Name = "button1";
            button1.Size = new Size(34, 29);
            button1.TabIndex = 24;
            button1.Text = "-";
            button1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(495, 391);
            button3.Name = "button3";
            button3.Size = new Size(34, 29);
            button3.TabIndex = 25;
            button3.Text = "-";
            button3.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(856, 684);
            button5.Name = "button5";
            button5.Size = new Size(34, 29);
            button5.TabIndex = 26;
            button5.Text = "-";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(495, 679);
            button6.Name = "button6";
            button6.Size = new Size(34, 29);
            button6.TabIndex = 27;
            button6.Text = "-";
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Location = new Point(856, 392);
            button7.Name = "button7";
            button7.Size = new Size(34, 29);
            button7.TabIndex = 28;
            button7.Text = "-";
            button7.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.Pink;
            label2.Location = new Point(935, 392);
            label2.Name = "label2";
            label2.Size = new Size(23, 28);
            label2.TabIndex = 29;
            label2.Text = "0";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.Pink;
            label3.Location = new Point(574, 392);
            label3.Name = "label3";
            label3.Size = new Size(23, 28);
            label3.TabIndex = 30;
            label3.Text = "0";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.Pink;
            label4.Location = new Point(935, 685);
            label4.Name = "label4";
            label4.Size = new Size(23, 28);
            label4.TabIndex = 31;
            label4.Text = "0";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = Color.Pink;
            label5.Location = new Point(574, 684);
            label5.Name = "label5";
            label5.Size = new Size(23, 28);
            label5.TabIndex = 32;
            label5.Text = "0";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.Pink;
            label6.Location = new Point(164, 676);
            label6.Name = "label6";
            label6.Size = new Size(23, 28);
            label6.TabIndex = 33;
            label6.Text = "0";
            // 
            // button8
            // 
            button8.ForeColor = Color.Pink;
            button8.Location = new Point(223, 379);
            button8.Name = "button8";
            button8.Size = new Size(34, 29);
            button8.TabIndex = 34;
            button8.Text = "+";
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.ForeColor = Color.Pink;
            button9.Location = new Point(640, 391);
            button9.Name = "button9";
            button9.Size = new Size(34, 29);
            button9.TabIndex = 35;
            button9.Text = "+";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.ForeColor = Color.Pink;
            button10.Location = new Point(993, 391);
            button10.Name = "button10";
            button10.Size = new Size(34, 29);
            button10.TabIndex = 36;
            button10.Text = "+";
            button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.ForeColor = Color.Pink;
            button11.Location = new Point(993, 684);
            button11.Name = "button11";
            button11.Size = new Size(34, 29);
            button11.TabIndex = 37;
            button11.Text = "+";
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.ForeColor = Color.Pink;
            button12.Location = new Point(631, 679);
            button12.Name = "button12";
            button12.Size = new Size(34, 29);
            button12.TabIndex = 38;
            button12.Text = "+";
            button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.ForeColor = Color.Pink;
            button13.Location = new Point(236, 679);
            button13.Name = "button13";
            button13.Size = new Size(34, 29);
            button13.TabIndex = 39;
            button13.Text = "+";
            button13.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.ForeColor = Color.Pink;
            label8.Location = new Point(173, 376);
            label8.Name = "label8";
            label8.Size = new Size(23, 28);
            label8.TabIndex = 40;
            label8.Text = "0";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.ForeColor = Color.LavenderBlush;
            label9.Location = new Point(563, 753);
            label9.Name = "label9";
            label9.Size = new Size(72, 28);
            label9.TabIndex = 41;
            label9.Text = "page 1";
            // 
            // instruments
            // 
            AutoScaleDimensions = new SizeF(11F, 28F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(1268, 1000);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(button4);
            Controls.Add(totalLabel);
            Controls.Add(label1);
            Controls.Add(panel1);
            Controls.Add(button2);
            Controls.Add(nextButton);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(checkBox6);
            Controls.Add(checkBox5);
            Controls.Add(checkBox4);
            Controls.Add(checkBox3);
            Controls.Add(checkBox2);
            Controls.Add(pictureBox1);
            Controls.Add(checkBox1);
            Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4);
            Name = "instruments";
            Text = "v";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox checkBox1;
        private PictureBox pictureBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private CheckBox checkBox4;
        private CheckBox checkBox5;
        private CheckBox checkBox6;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private Button nextButton;
        private Button button2;
        private Panel panel1;
        private Label label7;
        private Label label1;
        private Label totalLabel;
        private Button button4;
        private Button button1;
        private Button button3;
        private Button button5;
        private Button button6;
        private Button button7;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Label label8;
        private Label label9;
    }
}