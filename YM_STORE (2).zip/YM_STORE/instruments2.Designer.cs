﻿namespace YM_STORE
{
    partial class instruments2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(instruments2));
            panel1 = new Panel();
            label7 = new Label();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox4 = new CheckBox();
            checkBox5 = new CheckBox();
            checkBox6 = new CheckBox();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            button3 = new Button();
            button4 = new Button();
            label2 = new Label();
            button5 = new Button();
            label3 = new Label();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            label5 = new Label();
            label6 = new Label();
            label8 = new Label();
            label9 = new Label();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            label4 = new Label();
            totalLabel = new Label();
            label10 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.HotPink;
            panel1.Controls.Add(label7);
            panel1.Location = new Point(-18, -10);
            panel1.Name = "panel1";
            panel1.Size = new Size(1020, 74);
            panel1.TabIndex = 0;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.HotPink;
            label7.Font = new Font("Matura MT Script Capitals", 22.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.LavenderBlush;
            label7.Location = new Point(172, 19);
            label7.Name = "label7";
            label7.Size = new Size(544, 50);
            label7.TabIndex = 21;
            label7.Text = "MY  MUSIC STORE  ";
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox2.ForeColor = Color.Pink;
            checkBox2.Location = new Point(727, 293);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(97, 32);
            checkBox2.TabIndex = 2;
            checkBox2.Text = "7000LE";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox3.ForeColor = Color.Pink;
            checkBox3.Location = new Point(448, 293);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(97, 32);
            checkBox3.TabIndex = 3;
            checkBox3.Text = "6000LE";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox4.ForeColor = Color.Pink;
            checkBox4.Location = new Point(154, 614);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(97, 32);
            checkBox4.TabIndex = 4;
            checkBox4.Text = "7000LE";
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox5.ForeColor = Color.Pink;
            checkBox5.Location = new Point(475, 600);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(97, 32);
            checkBox5.TabIndex = 5;
            checkBox5.Text = "7680LE";
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBox6.ForeColor = Color.Pink;
            checkBox6.Location = new Point(748, 629);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(97, 32);
            checkBox6.TabIndex = 6;
            checkBox6.Text = "2155LE";
            checkBox6.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(118, 119);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(203, 141);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(404, 119);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(195, 141);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 8;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(684, 123);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(205, 140);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 9;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(91, 454);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(230, 140);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 10;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(405, 454);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(238, 140);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 11;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(715, 454);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(201, 156);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 12;
            pictureBox6.TabStop = false;
            // 
            // button1
            // 
            button1.ForeColor = Color.HotPink;
            button1.Location = new Point(532, 732);
            button1.Name = "button1";
            button1.Size = new Size(111, 49);
            button1.TabIndex = 13;
            button1.Text = "CHECK OUT";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.ForeColor = Color.HotPink;
            button2.Location = new Point(404, 732);
            button2.Name = "button2";
            button2.Size = new Size(115, 49);
            button2.TabIndex = 14;
            button2.Text = "BACK";
            button2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Pink;
            label1.Location = new Point(163, 294);
            label1.Name = "label1";
            label1.Size = new Size(91, 28);
            label1.TabIndex = 15;
            label1.Text = "9999EGP";
            // 
            // button3
            // 
            button3.ForeColor = Color.Pink;
            button3.Location = new Point(253, 341);
            button3.Name = "button3";
            button3.Size = new Size(34, 29);
            button3.TabIndex = 16;
            button3.Text = "+";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(118, 341);
            button4.Name = "button4";
            button4.Size = new Size(34, 29);
            button4.TabIndex = 17;
            button4.Text = "-";
            button4.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.Pink;
            label2.Location = new Point(195, 345);
            label2.Name = "label2";
            label2.Size = new Size(17, 20);
            label2.TabIndex = 18;
            label2.Text = "0";
            // 
            // button5
            // 
            button5.Location = new Point(405, 345);
            button5.Name = "button5";
            button5.Size = new Size(34, 29);
            button5.TabIndex = 19;
            button5.Text = "-";
            button5.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.Pink;
            label3.Location = new Point(475, 354);
            label3.Name = "label3";
            label3.Size = new Size(17, 20);
            label3.TabIndex = 20;
            label3.Text = "0";
            // 
            // button6
            // 
            button6.Location = new Point(547, 347);
            button6.Name = "button6";
            button6.Size = new Size(34, 34);
            button6.TabIndex = 21;
            button6.Text = "+";
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Location = new Point(836, 676);
            button7.Name = "button7";
            button7.Size = new Size(34, 29);
            button7.TabIndex = 22;
            button7.Text = "+";
            button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Location = new Point(836, 354);
            button8.Name = "button8";
            button8.Size = new Size(34, 29);
            button8.TabIndex = 23;
            button8.Text = "+";
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(241, 667);
            button9.Name = "button9";
            button9.Size = new Size(34, 29);
            button9.TabIndex = 24;
            button9.Text = "+";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(576, 653);
            button10.Name = "button10";
            button10.Size = new Size(34, 29);
            button10.TabIndex = 25;
            button10.Text = "+";
            button10.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = Color.Pink;
            label5.Location = new Point(789, 676);
            label5.Name = "label5";
            label5.Size = new Size(17, 20);
            label5.TabIndex = 27;
            label5.Text = "0";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = Color.Pink;
            label6.Location = new Point(511, 657);
            label6.Name = "label6";
            label6.Size = new Size(17, 20);
            label6.TabIndex = 28;
            label6.Text = "0";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.ForeColor = Color.Pink;
            label8.Location = new Point(195, 671);
            label8.Name = "label8";
            label8.Size = new Size(17, 20);
            label8.TabIndex = 29;
            label8.Text = "0";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.ForeColor = Color.Pink;
            label9.Location = new Point(778, 361);
            label9.Name = "label9";
            label9.Size = new Size(17, 20);
            label9.TabIndex = 30;
            label9.Text = "0";
            // 
            // button11
            // 
            button11.Location = new Point(417, 653);
            button11.Name = "button11";
            button11.Size = new Size(34, 29);
            button11.TabIndex = 31;
            button11.Text = "-";
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.Location = new Point(128, 667);
            button12.Name = "button12";
            button12.Size = new Size(34, 29);
            button12.TabIndex = 32;
            button12.Text = "-";
            button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.Location = new Point(704, 353);
            button13.Name = "button13";
            button13.Size = new Size(29, 30);
            button13.TabIndex = 33;
            button13.Text = "-";
            button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            button14.Location = new Point(727, 676);
            button14.Name = "button14";
            button14.Size = new Size(34, 29);
            button14.TabIndex = 34;
            button14.Text = "-";
            button14.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.LavenderBlush;
            label4.Location = new Point(490, 699);
            label4.Name = "label4";
            label4.Size = new Size(55, 20);
            label4.TabIndex = 42;
            label4.Text = "page 2";
            // 
            // totalLabel
            // 
            totalLabel.AutoSize = true;
            totalLabel.ForeColor = Color.Pink;
            totalLabel.Location = new Point(181, 746);
            totalLabel.Name = "totalLabel";
            totalLabel.Size = new Size(17, 20);
            totalLabel.TabIndex = 44;
            totalLabel.Text = "0";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.ForeColor = SystemColors.ButtonFace;
            label10.Location = new Point(77, 746);
            label10.Name = "label10";
            label10.Size = new Size(75, 20);
            label10.TabIndex = 43;
            label10.Text = "Total EGP:";
            // 
            // instruments2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(992, 793);
            Controls.Add(totalLabel);
            Controls.Add(label10);
            Controls.Add(label4);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(label3);
            Controls.Add(button5);
            Controls.Add(label2);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(checkBox6);
            Controls.Add(checkBox5);
            Controls.Add(checkBox4);
            Controls.Add(checkBox3);
            Controls.Add(checkBox2);
            Controls.Add(panel1);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.None;
            Name = "instruments2";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label7;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private CheckBox checkBox4;
        private CheckBox checkBox5;
        private CheckBox checkBox6;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private Button button1;
        private Button button2;
        private Label label1;
        private Button button3;
        private Button button4;
        private Label label2;
        private Button button5;
        private Label label3;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Label label5;
        private Label label6;
        private Label label8;
        private Label label9;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Label label4;
        private Label totalLabel;
        private Label label10;
    }
}