﻿namespace YMN_STORE
{
    partial class CreateAccount2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            lastName = new TextBox();
            phoneTextBox = new TextBox();
            emailTextBox = new TextBox();
            addressTextBox = new TextBox();
            panel1 = new Panel();
            label8 = new Label();
            button3 = new Button();
            button1 = new Button();
            button2 = new Button();
            panel2 = new Panel();
            button4 = new Button();
            ageTextBox = new TextBox();
            fnTextBox = new TextBox();
            errorMessage = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(34, 106);
            label1.Name = "label1";
            label1.Size = new Size(80, 20);
            label1.TabIndex = 1;
            label1.Text = "First Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(35, 149);
            label2.Name = "label2";
            label2.Size = new Size(79, 20);
            label2.TabIndex = 2;
            label2.Text = "Last Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(78, 196);
            label3.Name = "label3";
            label3.Size = new Size(36, 20);
            label3.TabIndex = 3;
            label3.Text = "Age";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(478, 106);
            label4.Name = "label4";
            label4.Size = new Size(108, 20);
            label4.TabIndex = 4;
            label4.Text = "Phone Number";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(540, 149);
            label5.Name = "label5";
            label5.Size = new Size(46, 20);
            label5.TabIndex = 5;
            label5.Text = "Email";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(524, 193);
            label6.Name = "label6";
            label6.Size = new Size(62, 20);
            label6.TabIndex = 6;
            label6.Text = "Address";
            // 
            // lastName
            // 
            lastName.Location = new Point(120, 146);
            lastName.Name = "lastName";
            lastName.Size = new Size(230, 27);
            lastName.TabIndex = 7;
            lastName.TextChanged += lastName_TextChanged;
            // 
            // phoneTextBox
            // 
            phoneTextBox.Location = new Point(592, 103);
            phoneTextBox.Name = "phoneTextBox";
            phoneTextBox.Size = new Size(174, 27);
            phoneTextBox.TabIndex = 9;
            phoneTextBox.TextChanged += phoneTextBox_TextChanged;
            // 
            // emailTextBox
            // 
            emailTextBox.Location = new Point(592, 150);
            emailTextBox.Name = "emailTextBox";
            emailTextBox.Size = new Size(174, 27);
            emailTextBox.TabIndex = 10;
            emailTextBox.TextChanged += emailTextBox_TextChanged;
            // 
            // addressTextBox
            // 
            addressTextBox.Location = new Point(592, 193);
            addressTextBox.Name = "addressTextBox";
            addressTextBox.Size = new Size(174, 27);
            addressTextBox.TabIndex = 11;
            addressTextBox.TextChanged += addressTextBox_TextChanged;
            // 
            // panel1
            // 
            panel1.BackColor = Color.HotPink;
            panel1.Controls.Add(label8);
            panel1.Controls.Add(button3);
            panel1.ForeColor = Color.HotPink;
            panel1.Location = new Point(-8, -39);
            panel1.Name = "panel1";
            panel1.Size = new Size(825, 118);
            panel1.TabIndex = 12;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Matura MT Script Capitals", 22.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.Control;
            label8.Location = new Point(30, 56);
            label8.Name = "label8";
            label8.Size = new Size(544, 50);
            label8.TabIndex = 3;
            label8.Text = "MY  MUSIC STORE  ";
            // 
            // button3
            // 
            button3.Font = new Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.Location = new Point(630, 63);
            button3.Name = "button3";
            button3.Size = new Size(118, 39);
            button3.TabIndex = 2;
            button3.Text = "home page ";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Showcard Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.HotPink;
            button1.Location = new Point(300, 306);
            button1.Name = "button1";
            button1.Size = new Size(194, 39);
            button1.TabIndex = 13;
            button1.Text = "confirm";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Showcard Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.HotPink;
            button2.Location = new Point(300, 351);
            button2.Name = "button2";
            button2.Size = new Size(194, 41);
            button2.TabIndex = 14;
            button2.Text = "reset";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.HotPink;
            panel2.Location = new Point(-8, 486);
            panel2.Name = "panel2";
            panel2.Size = new Size(812, 125);
            panel2.TabIndex = 15;
            // 
            // button4
            // 
            button4.Font = new Font("Showcard Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.HotPink;
            button4.Location = new Point(300, 398);
            button4.Name = "button4";
            button4.Size = new Size(194, 41);
            button4.TabIndex = 16;
            button4.Text = "back";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // ageTextBox
            // 
            ageTextBox.Location = new Point(120, 196);
            ageTextBox.Name = "ageTextBox";
            ageTextBox.Size = new Size(230, 27);
            ageTextBox.TabIndex = 17;
            ageTextBox.TextChanged += ageTextBox_TextChanged;
            // 
            // fnTextBox
            // 
            fnTextBox.Location = new Point(120, 103);
            fnTextBox.Name = "fnTextBox";
            fnTextBox.Size = new Size(230, 27);
            fnTextBox.TabIndex = 18;
            fnTextBox.TextChanged += fnTextBox_TextChanged;
            // 
            // errorMessage
            // 
            errorMessage.AutoSize = true;
            errorMessage.ForeColor = Color.Red;
            errorMessage.Location = new Point(279, 254);
            errorMessage.Name = "errorMessage";
            errorMessage.Size = new Size(0, 20);
            errorMessage.TabIndex = 19;
            // 
            // CreateAccount2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(800, 512);
            Controls.Add(errorMessage);
            Controls.Add(fnTextBox);
            Controls.Add(ageTextBox);
            Controls.Add(button4);
            Controls.Add(panel2);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(panel1);
            Controls.Add(addressTextBox);
            Controls.Add(emailTextBox);
            Controls.Add(phoneTextBox);
            Controls.Add(lastName);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            ForeColor = Color.Snow;
            FormBorderStyle = FormBorderStyle.None;
            Name = "CreateAccount2";
            Text = "CreateAccount2";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox firstName;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox lastName;
        private TextBox phoneTextBox;
        private TextBox emailTextBox;
        private TextBox addressTextBox;
        private Panel panel1;
        private Button button1;
        private Button button2;
        private Panel panel2;
        private Button button3;
        private Button button4;
        private Label label8;
        private TextBox ageTextBox;
        private TextBox fnTextBox;
        private Label errorMessage;
    }
}